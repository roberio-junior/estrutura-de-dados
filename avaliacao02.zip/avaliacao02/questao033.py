def resultado_pesquisa(pesquisa: str):
    print("╔════════════════════════════════════════════════════════════════╗")
    print("║ ◄   ►   ⟳  🔒 https://www.navegador.com/search?q=exemplo       ║")
    print("╠════════════════════════════════════════════════════════════════╣")

    tamanho = len(pesquisa)
    largura = 54
    if tamanho < 54:
        print(f"║ Pesquisa:{pesquisa}" + " " * (largura - tamanho) + "║")
    else:
        reduzida = ""
        for i in range (50):
            reduzida += pesquisa[i]
        print(f"║ Pesquisa:{reduzida}..." + " ║")

    print("║────────────────────────────────────────────────────────────────║")
    print("║ Primeiro Resultado                                             ║")
    print("║ 🌐 https://www.siteexemplo.com/artigo                          ║")
    print("║ Este é um breve resumo do conteúdo apresentado neste site.     ║")
    print("║────────────────────────────────────────────────────────────────║")
    print("║ Outro resultado relevante                                      ║")
    print("║ 🌐 https://www.outroexemplo.org/tema                           ║")
    print("║ Uma descrição genérica sobre o conteúdo relacionado à pesquisa.║")
    print("║────────────────────────────────────────────────────────────────║")
    print("║ Mais informações                                               ║")
    print("║ 🌐 https://www.informacoes.com/pagina                          ║")
    print("║ Texto resumido com possíveis explicações ou exemplos práticos. ║")
    print("╚════════════════════════════════════════════════════════════════╝")

palavra = "Ian é indiano?"

historico = []
atual = []
def menu():
    global historico
    texto = ""
    while True:
        print("\n╔══════════════════════════════╗")
        print("║       MENU                   ║")
        print("╠══════════════════════════════╣")
        print("║ 1. Escrever uma palavra      ║")
        print("║ 2. < Voltar                  ║")
        print("║ 3. > Avançar                 ║")
        print("║ 0. x Sair                    ║")
        print("╚══════════════════════════════╝")

        escolha = input("Escolha uma opção: ")

        if escolha == "1":
            palavra = input('Escreva uma palavra:')
            historico = []
            atual.append(palavra)
            texto += palavra
        elif escolha == "2":
            if len(atual) == 1:
                pass
            else:
                retorno = atual.pop()
                texto -= retorno
                historico.append(retorno)
        elif escolha == "3":
            if len(historico) == 0:
                pass
            else:
                avanco = historico.pop()
                texto += avanco
                atual.append(avanco)
        elif escolha == "0":
            print("Encerrando Navegador...")
            break
        else:
            print("Opção inválida. Tente novamente.")

        print(texto)

menu()